﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Module2_PRA
{
    public class Employee
    {
        private int employeeId;
        private string fullname;
        private double salary;
        private bool taxDeducted;

        // 1. Constructor: Employee (int employeeId, String fullName, float salary, bool taxDeducted)
        public Employee(int employeeId, string fullname, double salary, bool taxDeducted)
        {
            this.employeeId = employeeId;
            this.fullname = fullname;
            this.salary = salary;
            this.taxDeducted = taxDeducted;
        }

        // 2. Overloaded Constructor, w/out specifying tax status
        public Employee(int employeeId, string fullname, double salary) :this(employeeId, fullname, salary, false)
        {
        }

        // Getting ID
        public int EmployeeID
        {
            get
            {
                return employeeId;
            }
        }

        // Getting and setting fullNmae
        public string FullName
        {
            get
            {
                return fullname;
            }
        }

        // 3. Getting and setting salary
        public double getNetSalary
        {
            get
            {
                return salary;
            }
        }

        // Getting and setting tax status
        public bool TaxDeducted
        {
            get
            {
                return taxDeducted;
            }
            set
            {
                taxDeducted = value;
            }
        }

        // 4. printInformation - prints out employee's info
        public void printInformation()
        {
            Console.WriteLine("ID: {0}",employeeId);
            Console.WriteLine("Full Name: {0}",fullname);
            Console.WriteLine("Net Salary: {0}", salary * 0.8);
            Console.WriteLine("Tax Deducted: {0}", taxDeducted);
        }
    }
    public class WeeklyEmployee : Employee
    {
        public WeeklyEmployee(int employeeId, string fullname, double salary, bool taxDeducted)
            :base(employeeId, fullname, salary, taxDeducted)
        {
        }
        public WeeklyEmployee(int employeeId, string fullname, double salary) :this(employeeId, fullname, salary, false)
        {
        }
    }
}// the end
